public interface SerialListener {

    void next(String data);

    void onFinish();
}
